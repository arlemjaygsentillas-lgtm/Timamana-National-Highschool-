import { GraduationCap } from "lucide-react"
import Link from "next/link"

export function Footer() {
  return (
    <footer className="bg-foreground py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary-foreground/10 flex items-center justify-center">
              <GraduationCap className="w-6 h-6 text-primary-foreground" />
            </div>
            <div>
              <span className="font-serif text-lg font-semibold text-primary-foreground">
                Timamana NHS
              </span>
              <p className="text-primary-foreground/50 text-xs">
                Advancing Together With Purpose
              </p>
            </div>
          </div>
          
          <nav className="flex flex-wrap justify-center gap-6">
            <Link href="#home" className="text-sm text-primary-foreground/60 hover:text-primary-foreground transition-colors">
              Home
            </Link>
            <Link href="#about" className="text-sm text-primary-foreground/60 hover:text-primary-foreground transition-colors">
              About
            </Link>
            <Link href="#academics" className="text-sm text-primary-foreground/60 hover:text-primary-foreground transition-colors">
              Academics
            </Link>
            <Link href="#contact" className="text-sm text-primary-foreground/60 hover:text-primary-foreground transition-colors">
              Contact
            </Link>
          </nav>
        </div>
        
        <div className="border-t border-primary-foreground/10 mt-8 pt-8">
          <p className="text-center text-primary-foreground/40 text-sm">
            © {new Date().getFullYear()} Timamana National Highschool. School Subject Project.
          </p>
        </div>
      </div>
    </footer>
  )
}
