import { BookOpen, Users, Award } from "lucide-react"

export function HeroSection() {
  return (
    <section id="home" className="relative min-h-screen flex items-center pt-20 bg-primary">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:4rem_4rem]" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="max-w-3xl">
          <p className="text-accent text-sm font-medium tracking-widest uppercase mb-4">
            Advancing Together With Purpose And Responsibility
          </p>
          
          <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold text-primary-foreground leading-tight mb-6 text-balance">
            Timamana National Highschool
          </h1>
          
          <p className="text-xl sm:text-2xl text-primary-foreground/80 font-light mb-8">
            Education for a Better Future
          </p>
          
          <p className="text-primary-foreground/70 text-lg leading-relaxed mb-12 max-w-2xl">
            Welcome to the official academic website of Timamana National Highschool. 
            This website was created as part of a school subject project. It aims to provide 
            basic information about the school, its academic programs, and student activities 
            in a simple and organized way.
          </p>
          
          <div className="flex flex-wrap gap-8">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-primary-foreground/10 flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-accent" />
              </div>
              <div>
                <p className="text-primary-foreground font-semibold">Quality</p>
                <p className="text-primary-foreground/60 text-sm">Education</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-primary-foreground/10 flex items-center justify-center">
                <Users className="w-6 h-6 text-accent" />
              </div>
              <div>
                <p className="text-primary-foreground font-semibold">Strong</p>
                <p className="text-primary-foreground/60 text-sm">Community</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-primary-foreground/10 flex items-center justify-center">
                <Award className="w-6 h-6 text-accent" />
              </div>
              <div>
                <p className="text-primary-foreground font-semibold">Academic</p>
                <p className="text-primary-foreground/60 text-sm">Excellence</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
