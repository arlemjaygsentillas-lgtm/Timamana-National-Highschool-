import { BookOpen, Lightbulb, TrendingUp } from "lucide-react"

const academicFeatures = [
  {
    icon: BookOpen,
    title: "Structured Learning",
    description: "Comprehensive curriculum designed to meet educational standards and student needs"
  },
  {
    icon: Lightbulb,
    title: "Guided Instruction",
    description: "Dedicated teachers providing quality instruction and mentorship"
  },
  {
    icon: TrendingUp,
    title: "Personal Development",
    description: "Activities that support academic growth and character building"
  }
]

export function AcademicsSection() {
  return (
    <section id="academics" className="py-20 lg:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <p className="text-accent text-sm font-medium tracking-widest uppercase mb-4">
              Academic Information
            </p>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-foreground mb-6">
              Preparing Students for Success
            </h2>
            <p className="text-muted-foreground text-lg leading-relaxed mb-8">
              Timamana National Highschool offers different academic programs designed to 
              meet the needs of students. The school provides structured learning, guided 
              instruction, and activities that support academic growth and personal development.
            </p>
            
            <div className="space-y-6">
              {academicFeatures.map((feature, index) => (
                <div key={index} className="flex gap-4">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground mb-1">
                      {feature.title}
                    </h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="bg-primary rounded-lg p-8 lg:p-12">
            <div className="space-y-8">
              <div>
                <p className="text-accent text-sm font-medium uppercase tracking-wider mb-2">
                  Academic Programs
                </p>
                <h3 className="font-serif text-2xl font-bold text-primary-foreground mb-4">
                  Junior & Senior High School
                </h3>
                <p className="text-primary-foreground/70 leading-relaxed">
                  We offer comprehensive programs for both Junior High School (Grades 7-10) 
                  and Senior High School (Grades 11-12) with various tracks and strands.
                </p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-primary-foreground/10 rounded-lg p-4">
                  <p className="text-3xl font-bold text-primary-foreground mb-1">JHS</p>
                  <p className="text-primary-foreground/60 text-sm">Grades 7-10</p>
                </div>
                <div className="bg-primary-foreground/10 rounded-lg p-4">
                  <p className="text-3xl font-bold text-primary-foreground mb-1">SHS</p>
                  <p className="text-primary-foreground/60 text-sm">Grades 11-12</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
