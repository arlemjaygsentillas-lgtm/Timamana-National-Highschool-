import { Trophy, Palette, Music, Users } from "lucide-react"

const activities = [
  {
    icon: Trophy,
    title: "Sports",
    description: "Athletics, basketball, volleyball, and more"
  },
  {
    icon: Palette,
    title: "Arts & Culture",
    description: "Creative expression through various art forms"
  },
  {
    icon: Music,
    title: "Clubs",
    description: "Academic and interest-based organizations"
  },
  {
    icon: Users,
    title: "School Events",
    description: "Celebrations, programs, and community activities"
  }
]

export function ActivitiesSection() {
  return (
    <section id="activities" className="py-20 lg:py-32 bg-secondary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="text-accent text-sm font-medium tracking-widest uppercase mb-4">
            Student Life
          </p>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-foreground mb-6">
            Student Activities
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            The school encourages students to participate in various activities such as 
            clubs, sports, and school events. These activities help students build 
            teamwork, leadership, and confidence.
          </p>
        </div>
        
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {activities.map((activity, index) => (
            <div 
              key={index}
              className="group bg-card border border-border rounded-lg p-6 hover:border-primary/30 hover:shadow-lg transition-all duration-300"
            >
              <div className="w-14 h-14 rounded-lg bg-accent/10 flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                <activity.icon className="w-7 h-7 text-accent" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">
                {activity.title}
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {activity.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
