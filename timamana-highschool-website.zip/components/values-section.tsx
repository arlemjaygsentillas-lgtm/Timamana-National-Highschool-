import { Shield, Heart, Scale, Users, Star } from "lucide-react"

const coreValues = [
  {
    icon: Shield,
    title: "Responsibility",
    description: "Taking ownership of our actions and commitments"
  },
  {
    icon: Heart,
    title: "Respect",
    description: "Honoring the dignity and worth of every individual"
  },
  {
    icon: Scale,
    title: "Integrity",
    description: "Upholding honesty and strong moral principles"
  },
  {
    icon: Users,
    title: "Teamwork",
    description: "Working together to achieve common goals"
  },
  {
    icon: Star,
    title: "Excellence",
    description: "Striving for the highest standards in all endeavors"
  }
]

export function ValuesSection() {
  return (
    <section className="py-20 lg:py-32 bg-secondary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="text-accent text-sm font-medium tracking-widest uppercase mb-4">
            What We Stand For
          </p>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-foreground">
            Our Core Values
          </h2>
        </div>
        
        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-6">
          {coreValues.map((value, index) => (
            <div 
              key={index}
              className="bg-card border border-border rounded-lg p-6 text-center hover:shadow-lg hover:-translate-y-1 transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <value.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">
                {value.title}
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {value.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
