import { Target, Eye } from "lucide-react"

export function AboutSection() {
  return (
    <section id="about" className="py-20 lg:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-16">
          <p className="text-accent text-sm font-medium tracking-widest uppercase mb-4">
            About Our School
          </p>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-foreground mb-6">
            Building Foundations for Tomorrow
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Timamana National Highschool is an educational institution committed to providing 
            quality education to students. The school focuses on developing knowledge, skills, 
            and good values to help learners prepare for their future responsibilities in society.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-card border border-border rounded-lg p-8 hover:shadow-lg transition-shadow">
            <div className="w-14 h-14 rounded-lg bg-primary/10 flex items-center justify-center mb-6">
              <Target className="w-7 h-7 text-primary" />
            </div>
            <h3 className="font-serif text-xl font-semibold text-foreground mb-4">
              Our Mission
            </h3>
            <p className="text-muted-foreground leading-relaxed">
              To provide accessible and quality education that helps students develop 
              academically, socially, and morally.
            </p>
          </div>
          
          <div className="bg-card border border-border rounded-lg p-8 hover:shadow-lg transition-shadow">
            <div className="w-14 h-14 rounded-lg bg-accent/10 flex items-center justify-center mb-6">
              <Eye className="w-7 h-7 text-accent" />
            </div>
            <h3 className="font-serif text-xl font-semibold text-foreground mb-4">
              Our Vision
            </h3>
            <p className="text-muted-foreground leading-relaxed">
              To be a school that nurtures responsible, skilled, and confident learners 
              ready for the future.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
