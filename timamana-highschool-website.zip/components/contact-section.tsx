import { MapPin, Mail, Phone } from "lucide-react"

export function ContactSection() {
  return (
    <section id="contact" className="py-20 lg:py-32 bg-primary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
          <div>
            <p className="text-accent text-sm font-medium tracking-widest uppercase mb-4">
              Get In Touch
            </p>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-primary-foreground mb-6">
              Contact Information
            </h2>
            <p className="text-primary-foreground/70 text-lg leading-relaxed mb-8">
              Have questions or need more information? Feel free to reach out to us 
              through any of the contact details below.
            </p>
          </div>
          
          <div className="space-y-6">
            <div className="flex items-start gap-4 bg-primary-foreground/5 rounded-lg p-6">
              <div className="w-12 h-12 rounded-lg bg-primary-foreground/10 flex items-center justify-center shrink-0">
                <MapPin className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h3 className="font-semibold text-primary-foreground mb-1">
                  Address
                </h3>
                <p className="text-primary-foreground/70 leading-relaxed">
                  Timamana, Tubod, Surigao Del Norte
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-4 bg-primary-foreground/5 rounded-lg p-6">
              <div className="w-12 h-12 rounded-lg bg-primary-foreground/10 flex items-center justify-center shrink-0">
                <Mail className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h3 className="font-semibold text-primary-foreground mb-1">
                  Email
                </h3>
                <a 
                  href="mailto:school@email.com" 
                  className="text-primary-foreground/70 hover:text-accent transition-colors"
                >
                  school@email.com
                </a>
              </div>
            </div>
            
            <div className="flex items-start gap-4 bg-primary-foreground/5 rounded-lg p-6">
              <div className="w-12 h-12 rounded-lg bg-primary-foreground/10 flex items-center justify-center shrink-0">
                <Phone className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h3 className="font-semibold text-primary-foreground mb-1">
                  Phone
                </h3>
                <a 
                  href="tel:09486940982" 
                  className="text-primary-foreground/70 hover:text-accent transition-colors"
                >
                  0948 694 0982
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
