import { Bell, Calendar, FileText } from "lucide-react"

const announcements = [
  {
    icon: Calendar,
    title: "Enrollment Schedules",
    description: "Enrollment schedules will be posted regularly. Stay tuned for updates."
  },
  {
    icon: Bell,
    title: "School Events",
    description: "School events and activities will be announced here."
  },
  {
    icon: FileText,
    title: "Academic Reminders",
    description: "Important academic reminders will be shared with students."
  }
]

export function AnnouncementsSection() {
  return (
    <section id="announcements" className="py-20 lg:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-16">
          <p className="text-accent text-sm font-medium tracking-widest uppercase mb-4">
            Stay Updated
          </p>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-foreground">
            Announcements
          </h2>
        </div>
        
        <div className="grid md:grid-cols-3 gap-6">
          {announcements.map((item, index) => (
            <div 
              key={index}
              className="bg-card border border-border rounded-lg p-6 hover:shadow-lg transition-shadow"
            >
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                <item.icon className="w-5 h-5 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">
                {item.title}
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>
        
        <div className="mt-12 bg-primary/5 border border-primary/20 rounded-lg p-6 md:p-8">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
              <Bell className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-2">
                Important Notice
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                Please check this section regularly for updates on enrollment, school 
                activities, and other important announcements. You may also contact the 
                school administration for inquiries.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
